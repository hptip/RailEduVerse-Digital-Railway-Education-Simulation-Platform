# Thay đổi G0/G1 và điểm khôi phục

- File `AGENTS.md` ở project root chứa quy tắc bổ sung. Kiểm kê lúc bắt đầu không thấy AGENTS.md ở root.
- `InfrastructureG1.cs`, `InfrastructureG1Modules.cs`, `InfrastructureG1Land.cs` và `InfrastructureG1Review.cs` dưới `Assets/Editor` chứa đo đạc, generator, kiểm thử và xuất ảnh. Bộ chạy SO 201 được bổ sung lệnh `infrastructure-g1`. Menu Unity tương ứng là **Tools → UTTVR → Infrastructure → Generate and validate G1**.
- Scene và asset đầu ra riêng tại `Assets/ExternalBIM/InfrastructureG1`. Các script kiểm kê nguồn miễn phí nằm trong `Documentation/InfrastructureDesign/Tools`.
- `Temp/InfrastructureG1/Before_G1.zip` là snapshot Git của các đường dẫn đã kiểm kê. `Protected_Baseline.sha256` ghi SHA-256 bản trước khi chạy. Đợt import IFC tự động của Unity đã làm thay đổi prefab tàu. Nội dung trước tác vụ được khôi phục từ baseline trước phép kiểm cuối. Bản IFC/FBX/BLEND vẫn theo hash Source Manifest.
- Để hoàn tác G1, đóng scene mẫu nếu đang mở, sau đó hoàn tác riêng các file G1 và dòng lệnh đã thêm vào watcher. Giữ lại các nguồn người dùng đã đặt. Các scene sản phẩm và cầu SO 201 không cần rollback.
