# Evidence
Thư mục đầu ra của Codex. Chưa có kết quả triển khai. Dùng Templates/ để bắt đầu. Không lưu snapshot hoặc file nguồn vào đây nếu có hạn chế license. Các test geometry thực sự chạy trong Unity, kèm thông số và ảnh; Web chạy trình duyệt thật. Không xem ảnh concept là ảnh nghiệm thu.
