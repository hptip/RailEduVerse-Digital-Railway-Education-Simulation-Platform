# G1 · Bộ mẫu để duyệt trực quan

Scene Unity nằm tại `Assets/ExternalBIM/InfrastructureG1/Infrastructure_G1.unity`. Các mẫu nằm trong từng nhóm riêng để có thể đối chiếu ảnh và mở bằng Unity Editor. Trạng thái duyệt của người dùng là **PENDING**.

| Nhóm | Ảnh Unity | Phần cần xem |
| --- | --- | --- |
| OCL | [Đường thường](Screenshots/OCL_OpenTrack.png), [Cầu](Screenshots/OCL_Bridge.png), [Hầm](Screenshots/OCL_Tunnel.png), [Ga](Screenshots/OCL_Station.png), [Chi tiết](Screenshots/OCL_Detail.png) | Thân H, bản đế, bu lông, sứ, dây chịu lực, dây tiếp xúc, dây treo và khác biệt giữa các kiểu gá. Mẫu ga cần kiểm chứng với mái ga thật. |
| Hầm | [Cửa núi rừng](Screenshots/Tunnel_Forest_Portal.png), [Cửa núi đá](Screenshots/Tunnel_Rock_Portal.png), [Nội thất](Screenshots/Tunnel_Interior.png) | Phần núi bao trên cửa, tường cánh, lòng hầm hai ray, mối ghép vòng, rãnh, máng, đèn, lan can và thiết bị kỹ thuật. |
| Nền | [Tự nhiên](Screenshots/Subgrade_Natural.png), [Gia cố](Screenshots/Subgrade_Reinforced.png), [Tường chắn](Screenshots/Subgrade_RetainingWall.png), [Ô hình thoi](Screenshots/Subgrade_Diamond.png) | Màu các lớp, ô gia cố hai bên, tấm tường, rãnh và máng cáp riêng. Đối chiếu [mẫu IFC](Screenshots/Subgrade_IFC_Comparison.png) với [nền đang dùng](Screenshots/Subgrade_Existing_Comparison.png). |
| BIM | [Tách lớp](Screenshots/BIM_Exploded.png), [Mặt cắt](Screenshots/BIM_Section.png), [Cô lập](Screenshots/BIM_Isolation.png) | Xem cả các lớp khuất. Bộ kiểm thử dùng catalog/ID, raycast vào MeshCollider và thử phục hồi vị trí, lưới, vật liệu sau reset. |

## Số liệu dùng để dựng mẫu

`Resolved_Geometry.json` ghi phép đo ray và bao tàu từ Unity, nguồn dựng hình, ngưỡng và giả định dùng cho từng mẫu. Khoảng cách cột, định vị dây, chiều dày vòng và các lớp nền dùng ở G1 là tham số mô phỏng. Ảnh concept chỉ được dùng để đối chiếu hình thức.

## Nguồn và phạm vi

Unity đọc 65 mesh FBX. Thân chính của cụm nhập cao khoảng 3,977 m theo renderer, thấp hơn đỉnh bao tàu tại mẫu. Mẫu OCL dùng cột H dựng theo bao tàu hiện hành. LoD5 có vành ngoài khoảng 8,400 m và một đường ray. Mẫu hầm hai ray dùng vòng tham số với từng tấm riêng. Tệp IFC nền chỉ cung cấp hai lưới địa hình và đất đắp, nên mẫu nền dùng sáu lớp hình học sinh riêng. File BLEND và điều kiện phát hành nguồn còn chờ kiểm chứng.

Lượt này chỉ kiểm thử Edit Mode. Mount tại cầu được đối chiếu với tam giác mặt bản cầu SO 201; tiếp xúc pantograph và khoảng hở mái ga thực tế chưa đạt mức xác minh G1 đầy đủ.
