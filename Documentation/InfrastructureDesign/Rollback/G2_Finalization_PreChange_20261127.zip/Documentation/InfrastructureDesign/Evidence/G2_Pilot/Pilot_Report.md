# G2 Pilot · YenTuHaLongXanh

## Phạm vi

Mở `Assets/ExternalBIM/InfrastructureG2Pilot/Infrastructure_G2_Pilot.unity`. Scene dùng hai đường ray MicroChunk, terrain, ga đầu và cầu SO 201 540,121 m lấy từ tuyến hiện hành. Công trình thử nghiệm nằm trong nhóm **02 · Visual Pilot**. Có thể tắt nhóm này và bật **Công trình trước Pilot** trong Hierarchy để so sánh. **03 · Detailed mẫu theo cụm** mặc định tắt để tránh hiển thị trùng.

Scene là khu vực thử nghiệm Edit Mode. Unity mở lại scene đã lưu và xác minh 1.227 tham chiếu mesh và 228 binding Detailed. Registry sản phẩm giữ nguyên 17 Zone. Tuyến, spline, tàu, XR, cơ sở dữ liệu và cầu đã duyệt được bảo vệ bằng 129 checksum. Snapshot rollback có 143 mục, trong đó 129 bản lưu đối chiếu đúng từng checksum.

[Snapshot rollback](../../Rollback/G2_Pilot_PreIntegration_20261127.zip)

## Hầm và nền

- Registry xác nhận **Forest_02 tại Zone_013, 1.100–1.700 m**, và **Forest_01 tại Zone_015, 2.200–2.800 m**. Mỗi hầm dùng 250 vòng dài 2,4 m, 11 tấm mỗi vòng, tổng cộng **5.500 tấm vỏ**. Vỏ và thiết bị lấy từ mẫu G1. Hình học cửa, đáy, lối đi, rãnh, máng và lan can bám hệ trục spline. Hai ray hiển thị từ dữ liệu tuyến.
- Núi sinh theo từng đoạn 50 m với nền chân dốc lấy mẫu từ terrain thật. Đã kiểm tra hàng đỉnh chung giữa các đoạn, mái che phủ và vị trí đỉnh cây so với tiết diện lòng hầm. Các phép đo dùng tam giác và điểm mẫu, chưa chứng nhận thể tích kín cho toàn bộ địa hình. Ảnh mặt cắt dùng mặt phẳng cắt qua camera Unity, nên không có màu tô địa chất.
- Zone_010–011 dùng phạm vi **300–800 m** của manifest hiện hành. Ba mẫu nền sáu lớp vẫn có trong generator. Địa hình đo được ở các vị trí thử cho phương án nền tự nhiên. Các lớp khuất giữ trong định danh Detailed và được loại khỏi Visual. Chi tiết nối nền ở đầu đoạn vẫn cần duyệt trực quan.

## OCL

| Khu vực | Bố trí hoặc kết quả |
| --- | --- |
| Đường thường | 13 vị trí giữa 3.000 và 3.500 m. Bước thử 41,667 m theo mật độ khu OCL hiện hành. |
| SO 201 | 15 vị trí, từ 3.704,001 đến 4.224,122 m. Các góc chân cột có tam giác bản mặt cầu bên dưới. Phép thử này xác minh mặt đỡ, giới hạn khoảng hở tới gờ mép cầu cần đo thêm. |
| Hai hầm | 21 vị trí giá đỡ mỗi hầm, bước 29,700 m. Bốn đoạn chuyển tiếp nối đầu dây trong hầm với cột ngoài. Các điểm nối dây trong từng phạm vi được so sánh theo tọa độ thế giới. |
| Ga đầu | Khảo sát 79.706 tam giác của model ga thật trong phạm vi chiếu 0–51,897 m. Tại vị trí thử 0 m, hai thân cột giao hình học ga và một chân thiếu mặt đỡ. Đã tìm trong dải cho phép với thay đổi vị trí và bề rộng cổng. Vị trí lỗi và nhịp dây phụ thuộc được loại khỏi scene lưu. Còn một cổng mẫu tại 51,897 m. Phủ OCL liên tục trong phạm vi ga và khoảng hở mái dương vẫn chưa đạt. |

Bao quét được lấy mẫu dọc cả tuyến mỗi mét, áp dụng bề dài hai toa, khoảng cách toa và offset hiện có trên cả hai đường. Dây mẫu cao hơn đỉnh bao tính toán khoảng 0,809 m. Khoảng hở ngang bảo thủ tới thành hầm khoảng 1,786 m. Đây là kiểm tra hình học; mặt tiếp xúc và hành trình pantograph vẫn **NOT VERIFIED**.

## Hình học, nguồn và hiệu năng

- 288 kết quả G1 được dùng làm baseline cho bộ mẫu. CSV Pilot ghi các phép đo bổ sung trên bố trí tuyến đã sinh. Đã kiểm tra lại adapter, clip mesh 16 bit dùng bởi cấu kiện nhỏ, Exploded, Section, Isolation và Reset trên mẫu Detailed.
- `PilotGeometry.asset` chứa mesh và material của ứng viên. Unity kiểm tra tham chiếu trực tiếp, ô texture và dependency đệ quy. Ứng viên sinh tham số độc lập với IFC, FBX và BLEND chưa rõ quyền. Scene đối chiếu vẫn có tài nguyên hiện hành của project. **SRC-02 vẫn BLOCKED.** Ngoại lệ đề nghị chỉ áp dụng cho geometry/material của ứng viên, sau khi người dùng duyệt.
- Visual chia theo nhóm vật liệu và chunk 50 m, có 459 renderer và 943.872 tam giác tổng cộng cho các ứng viên, chưa tính môi trường đối chiếu. Không có collider chi tiết hay đèn realtime gắn theo từng vòng hầm. Lớp Detailed lưu mẫu chọn được trong từng domain. Registry ghi 13.998 occurrence với ID duy nhất. Trình nạp Detailed theo vùng cho toàn tuyến chưa triển khai. Chưa đo FPS hoặc bộ nhớ trên Web/Quest.
- **OCL-03 vẫn BLOCKED.** Khoảng hở hình học với tàu và điểm đỡ mẫu trên cầu có kết quả riêng. Đề nghị giới hạn OCL ở mô phỏng trực quan sau khi xử lý gá ga, khoảng hở mái và xác nhận rõ phạm vi pantograph.

## Ảnh Unity

- OCL [trước](Screenshots/OCL_Open_Before.png), [đường thường](Screenshots/OCL_Open.png), [SO 201](Screenshots/OCL_SO201.png), [ga](Screenshots/OCL_Station.png), [trong hầm](Screenshots/Forest_01_Interior_OCL.png).
- Forest_01 [trước](Screenshots/Forest_01_Portal_Before.png), [cửa hầm](Screenshots/Forest_01_Portal.png), [toàn vùng từ trên cao](Screenshots/Forest_01_Mountain.png), [cabin mô phỏng](Screenshots/Forest_01_Cabin.png), [mặt cắt](Screenshots/Forest_01_Section.png).
- Forest_02 [trước](Screenshots/Forest_02_Portal_Before.png), [cửa hầm](Screenshots/Forest_02_Portal.png), [toàn vùng từ trên cao](Screenshots/Forest_02_Mountain.png), [cabin mô phỏng](Screenshots/Forest_02_Cabin.png), [mặt cắt](Screenshots/Forest_02_Section.png).
- Nền [trước](Screenshots/Subgrade_Before.png), [Pilot](Screenshots/Subgrade.png).

Đã đối chiếu 18 ảnh Unity và ghi nhận 127 phép kiểm đạt. Ba phép kiểm chưa đạt đều thuộc ga, gồm mặt đỡ chân cột, giao cắt cấu kiện và phủ liên tục. Đối chiếu [kiểm tra hình học](Geometry_Test_Results.csv), [ước lượng hiệu năng](Performance_Estimate.csv) và [đăng ký cấu kiện](Asset_Registry.csv). Chờ duyệt Pilot và các ngoại lệ trước G2 Production.
