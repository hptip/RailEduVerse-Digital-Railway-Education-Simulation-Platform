# Trạng thái G1 Visual Refinement · 27/11/2026

Design Baseline v1.0 đã được người dùng duyệt. Duyệt trực quan bộ mẫu G1 vẫn **PENDING**.

| Cổng | Trạng thái | Kết quả |
| --- | --- | --- |
| G0 | BLOCKED một phần | Preflight khớp 4/4 SHA-256. Đã đo nguồn và baseline tuyến trong Unity. SRC-02 còn thiếu đối chiếu BLEND bằng Blender và bằng chứng quyền phát hành. |
| G1 | Chờ duyệt hình thức | Đã lưu mẫu tinh chỉnh cho bốn biến thể OCL, hai hầm và cảnh quan, ba kiểu nền sáu lớp và ba chế độ BIM. 288/288 phép kiểm Unity đạt. Còn hai tiêu chí BLOCKED gồm SRC-02 và OCL-03. |
| G2 | NOT_RUN | Giữ nguyên scene sản phẩm. |
| G3 | NOT_RUN | Web chưa build. VR NOT_TESTED. |

## Các điểm đã chốt bằng phép đo

- Khoảng cách tim hai ray tại mẫu đo là 6,39992 m. Cao độ đáy module ray là 8,93095 m theo tọa độ world. Nửa bề rộng bao quét bảo thủ là 1,76510 m, đỉnh tàu cao 5,57327 m so với đầu ray.
- Mẫu hầm đôi có khẩu độ trong 13,50 m. Chiều cao, khẩu độ và các giả định dựng mẫu được ghi riêng trong `Evidence/Resolved_Geometry.json`.
- SO 201 hiện hành vẫn dài 540,121 m, có 196 mesh ở Zone_018. Đối chiếu cuối khớp cả 129 hash file được bảo vệ. Registry giữ nguyên 17 Zone.
- OCL-03 có bốn mẫu và đã kiểm tra tam giác bản mặt SO 201 tại vị trí gắn chân. Đã đo mesh mái ga đầu trong hành lang ray và khảo sát phần nóc đoàn tàu. Thiếu giao điểm mái có thể đo trong hành lang và thiếu mặt tiếp xúc pantograph xác định được.
- Hai mẫu hầm dài 36 m theo 15 bước vòng 2,4 m. Giữ mặt cắt và sáu lớp nền đã xác minh. Mẫu ray dài dùng chỉ số mesh 32 bit để giữ đủ tam giác của lưới tham chiếu sau cắt.
- Nguồn sáng đặt cạnh từng cụm đèn được chọn trên thành hầm. Vị trí nguồn sáng được đo riêng vì gốc Transform của mesh đèn nằm ở gốc mô-đun.
- Catalog có 1.382 cấu kiện, giữ đủ 840 AssetID từ G1 ban đầu. Hình học quản lý BIM sinh tham số. 17 ảnh ban đầu được đối chiếu SHA-256 với gói Evidence trước đó.

## Dấu vân tay và cách chạy lại

- Unity scene `Assets/ExternalBIM/InfrastructureG1/Infrastructure_G1.unity`.
- Generator và kiểm thử `Assets/Editor/InfrastructureG1*.cs`. Dùng menu **Tools → UTTVR → Infrastructure → Generate and validate G1** trong Edit Mode. Công cụ dùng lại hàm lấy mẫu tam giác, cắt mesh, đo bao tàu và BIM adapter của SO 201.
- Hai lượt dựng cùng input có cùng SHA-256 hình học. Giá trị nằm tại `Evidence/Unity_Geometry_Fingerprint.txt`.
- Manifest ứng viên `Evidence/Candidate_Manifest.csv` ghi SHA-256 theo file. `G1_Refined_Evidence.zip` chứa ảnh Unity mới, 17 ảnh ban đầu và các bằng chứng kiểm thử.
- `py -3 Documentation/InfrastructureDesign/Tools/validate_kit.py preflight --project .`
- `py -3 Documentation/InfrastructureDesign/Tools/validate_kit.py gate --stage G1`

Xem `Evidence/Visual_Review.md` để duyệt OCL, hầm, nền và BIM Viewer. Chờ xác nhận trực quan của người dùng và xử lý các mục BLOCKED trước khi sang G2.
